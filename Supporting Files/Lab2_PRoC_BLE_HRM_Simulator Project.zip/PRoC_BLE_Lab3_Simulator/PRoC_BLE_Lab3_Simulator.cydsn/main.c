/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

uint16 HRM_Array[] = {500, 545, 600, 666, 750, 857, 1000};
uint16 PWMPeriod;
uint8 loadPWM;

CY_ISR(MyISR)
{
    if(loadPWM == 1)
    {
        TCPWM_4_WritePeriod(PWMPeriod);
        loadPWM = 0;
    }
    TCPWM_4_ClearInterrupt(TCPWM_4_INTR_MASK_TC);
}


int main()
{
    uint8 index = 0;
    
    CyGlobalIntEnable;
    
    TCPWM_4_Start();
    
    PWM_ISR_StartEx(MyISR);
    PWMPeriod = HRM_Array[index];
    loadPWM = 0;
    
    for(;;)
    {
        if(!SW1_Read())
        {
            CyDelay(5);
            if(!SW1_Read())
            {
                while(!SW1_Read());
                index++;
                if(index > 6)
                {
                    index = 0;
                }
                PWMPeriod = HRM_Array[index];
                loadPWM = 1;
            }
        }
    }
}

/* [] END OF FILE */
